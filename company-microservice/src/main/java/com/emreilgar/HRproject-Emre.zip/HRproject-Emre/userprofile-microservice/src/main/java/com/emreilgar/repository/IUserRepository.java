package com.emreilgar.repository;

public interface IUserRepository {
}
