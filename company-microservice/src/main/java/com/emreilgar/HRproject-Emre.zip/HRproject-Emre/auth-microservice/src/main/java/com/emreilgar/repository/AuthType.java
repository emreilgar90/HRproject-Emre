package com.emreilgar.repository;

public enum AuthType {
    USER,ADMIN,MANAGER,DIRECTOR
}
