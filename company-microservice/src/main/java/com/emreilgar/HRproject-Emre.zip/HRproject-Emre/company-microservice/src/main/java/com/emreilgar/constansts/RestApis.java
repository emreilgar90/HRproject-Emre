package com.emreilgar.constansts;

public class RestApis {
    public static final String VERSION="/v1";
    public static final String DEV = "/dev";

    public static final String TEST= "/test";

    public static final String CREATECOMPANY = "/createcompany";
    public static final String COMPANYFINDALL= "/findall";


    public static final String COMPANY = VERSION+DEV+"/company";
}
