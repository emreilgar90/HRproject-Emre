package com.emreilgar.entity;

public enum UserType {
    USER,ADMIN,MANAGER,DIRECTOR
}
