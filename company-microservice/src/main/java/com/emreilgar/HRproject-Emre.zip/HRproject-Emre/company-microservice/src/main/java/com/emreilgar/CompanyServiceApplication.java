package com.emreilgar;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Enable
public class CompanyServiceApplication {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}