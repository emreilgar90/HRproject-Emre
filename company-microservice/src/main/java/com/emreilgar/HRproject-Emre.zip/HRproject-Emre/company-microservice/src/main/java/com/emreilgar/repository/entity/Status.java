package com.emreilgar.repository.entity;

public enum Status {
    ACTIVE,PASSIVE
}
